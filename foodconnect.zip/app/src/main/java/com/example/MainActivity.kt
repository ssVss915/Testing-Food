package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import coil.compose.AsyncImage
import androidx.compose.ui.draw.clip
import com.example.ui.theme.MyApplicationTheme

enum class Role {
    NONE, PROVIDER, CUSTOMER
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        UserManager.init(applicationContext)
        setContent {
            MyApplicationTheme {
                var currentRole by remember { mutableStateOf(Role.NONE) }

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentRole) {
                            Role.NONE -> RoleSelectionScreen(
                                onRoleSelected = { currentRole = it }
                            )
                            Role.PROVIDER -> ProviderScreen(
                                onBack = { currentRole = Role.NONE }
                            )
                            Role.CUSTOMER -> {
                                var profileComplete by remember { mutableStateOf(UserManager.isProfileComplete()) }
                                if (!profileComplete) {
                                    UserProfileScreen(
                                        onComplete = { profileComplete = true },
                                        onBack = { currentRole = Role.NONE }
                                    )
                                } else {
                                    CustomerScreen(
                                        onBack = { currentRole = Role.NONE }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(onComplete: () -> Unit, onBack: () -> Unit) {
    var name by remember { mutableStateOf(UserManager.getProfile().name) }
    var phone by remember { mutableStateOf(UserManager.getProfile().phone) }
    var location by remember { mutableStateOf(UserManager.getProfile().location) }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profile Setup") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Delivery Location") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = {
                    if (name.isNotBlank() && phone.isNotBlank() && location.isNotBlank()) {
                        UserManager.saveProfile(UserProfile(name, phone, location))
                        onComplete()
                    } else {
                        Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("Save and Continue")
            }
        }
    }
}

@Composable
fun RoleSelectionScreen(onRoleSelected: (Role) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "FoodConnect",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "Select your app role",
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 48.dp)
        )

        Button(
            onClick = { onRoleSelected(Role.PROVIDER) },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("Restaurant Provider App", fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = { onRoleSelected(Role.CUSTOMER) },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.primary,
                containerColor = Color(0x66FFFFFF)
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x40FFFFFF))
        ) {
            Text("User / Customer App", fontSize = 16.sp)
        }
    }
}

enum class ProviderTab {
    MENU, PENDING_ORDERS, DELIVERED_ORDERS, SETTINGS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProviderScreen(onBack: () -> Unit) {
    var selectedTab by remember { mutableStateOf(ProviderTab.MENU) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Provider Dashboard") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                NavigationBarItem(
                    icon = { Text("🍔") },
                    label = { Text("Menu") },
                    selected = selectedTab == ProviderTab.MENU,
                    onClick = { selectedTab = ProviderTab.MENU }
                )
                NavigationBarItem(
                    icon = { Text("🕒") },
                    label = { Text("Pending") },
                    selected = selectedTab == ProviderTab.PENDING_ORDERS,
                    onClick = { selectedTab = ProviderTab.PENDING_ORDERS }
                )
                NavigationBarItem(
                    icon = { Text("✅") },
                    label = { Text("Delivered") },
                    selected = selectedTab == ProviderTab.DELIVERED_ORDERS,
                    onClick = { selectedTab = ProviderTab.DELIVERED_ORDERS }
                )
                NavigationBarItem(
                    icon = { Text("⚙️") },
                    label = { Text("Fees") },
                    selected = selectedTab == ProviderTab.SETTINGS,
                    onClick = { selectedTab = ProviderTab.SETTINGS }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (selectedTab) {
                ProviderTab.MENU -> ProviderMenuTab()
                ProviderTab.PENDING_ORDERS -> ProviderOrdersTab(OrderStatus.PENDING)
                ProviderTab.DELIVERED_ORDERS -> ProviderOrdersTab(OrderStatus.DELIVERED)
                ProviderTab.SETTINGS -> ProviderSettingsTab()
            }
        }
    }
}

@Composable
fun ProviderMenuTab() {
    val items by MenuRepository.menuItems.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var itemToEdit by remember { mutableStateOf<MenuItem?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
        ) {
            items(items) { item ->
                ProviderMenuItem(
                    item = item,
                    onEditClick = { itemToEdit = item }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
        
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Item")
        }
    }

    if (showAddDialog) {
        AddItemDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { item ->
                MenuRepository.addItem(item)
                showAddDialog = false
            }
        )
    }

    itemToEdit?.let { item ->
        EditItemDialog( // renamed to handle more edits
            item = item,
            onDismiss = { itemToEdit = null },
            onUpdate = { updates ->
                MenuRepository.updateItem(item.id, updates)
                itemToEdit = null
            }
        )
    }
}

@Composable
fun ProviderOrdersTab(status: OrderStatus) {
    val orders by OrderRepository.orders.collectAsState()
    val filteredOrders = orders.filter { it.status == status }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        if (filteredOrders.isEmpty()) {
            item {
                Text("No orders to show.", modifier = Modifier.padding(16.dp))
            }
        }
        items(filteredOrders) { order ->
            OrderCard(order = order, isProvider = true)
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun ProviderSettingsTab() {
    val config by AppConfigRepository.config.collectAsState()
    var deliveryFeeStr by remember(config) { mutableStateOf(config.deliveryFee.toString()) }
    var packagingFeeStr by remember(config) { mutableStateOf(config.packagingFee.toString()) }
    val context = LocalContext.current

    Column(modifier = Modifier.padding(24.dp).fillMaxSize()) {
        Text("Store Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = packagingFeeStr,
            onValueChange = { packagingFeeStr = it },
            label = { Text("Packaging Fee (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = deliveryFeeStr,
            onValueChange = { deliveryFeeStr = it },
            label = { Text("Delivery Fee (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = {
                val dFee = deliveryFeeStr.toDoubleOrNull()
                val pFee = packagingFeeStr.toDoubleOrNull()
                if (dFee != null && pFee != null) {
                    AppConfigRepository.updateFees(deliveryFee = dFee, packagingFee = pFee)
                    Toast.makeText(context, "Fees updated", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Invalid fees", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text("Save Fees")
        }
    }
}

@Composable
fun ProviderMenuItem(item: MenuItem, onEditClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(32.dp)),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                if (item.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model = item.imageUrl,
                        contentDescription = item.name,
                        modifier = Modifier.size(64.dp).clip(RoundedCornerShape(16.dp))
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                }
                Column {
                    Text(text = item.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    if (item.hasSizes) {
                        Text(text = "Half: ₹${item.halfPrice} | Full: ₹${item.fullPrice}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    } else {
                        Text(text = "₹${item.price}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            IconButton(onClick = onEditClick) {
                Icon(Icons.Default.Edit, contentDescription = "Edit Item")
            }
        }
    }
}

data class CartItem(val item: MenuItem, val size: String, val price: Double)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerScreen(onBack: () -> Unit) {
    val items by MenuRepository.menuItems.collectAsState()
    val config by AppConfigRepository.config.collectAsState()
    
    var cart by remember { mutableStateOf(mapOf<CartItem, Int>()) }
    val itemTotal = cart.entries.sumOf { it.key.price * it.value }
    val deliveryFee = if (itemTotal > 0) config.deliveryFee else 0.0
    val packagingFee = if (itemTotal > 0) config.packagingFee else 0.0
    val totalPrice = itemTotal + deliveryFee + packagingFee
    
    val context = LocalContext.current
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    var showEditProfile by remember { mutableStateOf(false) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                val profile = UserManager.getProfile()
                Column(
                    modifier = Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .background(MaterialTheme.colorScheme.primaryContainer, shape = androidx.compose.foundation.shape.CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Person, contentDescription = "Profile", modifier = Modifier.size(60.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(profile.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(profile.phone, color = Color.Gray)
                    Text(profile.location, color = Color.Gray, modifier = Modifier.padding(top = 4.dp))
                    Spacer(modifier = Modifier.height(32.dp))
                    Button(
                        onClick = {
                            coroutineScope.launch { drawerState.close() }
                            showEditProfile = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Edit Profile")
                    }
                }
            }
        }
    ) {
        if (showEditProfile) {
            UserProfileScreen(onComplete = { showEditProfile = false }, onBack = { showEditProfile = false })
        } else {
            Scaffold(
                topBar = {
                    Column(modifier = Modifier.padding(top = 48.dp, start = 16.dp, end = 16.dp, bottom = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Menu, contentDescription = "Logo", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("FoodConnect", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(Color.LightGray, shape = androidx.compose.foundation.shape.CircleShape)
                                        .clickable { coroutineScope.launch { drawerState.open() } },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Person, contentDescription = "Profile", tint = Color.DarkGray, modifier = Modifier.size(24.dp))
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Hello, ${UserManager.getProfile().name}! | Your Location: ${UserManager.getProfile().location}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.DarkGray
                        )
                    }
                },
        bottomBar = {
            if (itemTotal > 0) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 16.dp,
                    shadowElevation = 16.dp,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Item Total", color = Color.Gray)
                            Text("₹$itemTotal", fontWeight = FontWeight.SemiBold)
                        }
                        if (packagingFee > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Packaging Fee", color = Color.Gray)
                                Text("₹$packagingFee", fontWeight = FontWeight.SemiBold)
                            }
                        }
                        if (deliveryFee > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Delivery Fee", color = Color.Gray)
                                Text("₹$deliveryFee", fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)).padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("₹$totalPrice", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.onPrimary)
                                Text("TOTAL", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f))
                            }
                            TextButton(
                                onClick = {
                                    val userProfile = UserManager.getProfile()
                                    val orderItems = cart.map { entry ->
                                        OrderItem(
                                            menuItemId = entry.key.item.id,
                                            name = entry.key.item.name,
                                            quantity = entry.value,
                                            size = entry.key.size,
                                            price = entry.key.price
                                        )
                                    }
                                    val order = Order(
                                        userName = userProfile.name,
                                        userPhone = userProfile.phone,
                                        userLocation = userProfile.location,
                                        items = orderItems,
                                        itemTotal = itemTotal,
                                        deliveryFee = deliveryFee,
                                        packagingFee = packagingFee,
                                        totalAmount = totalPrice
                                    )
                                    OrderRepository.placeOrder(order)
                                    Toast.makeText(context, "Order Placed Successfully!", Toast.LENGTH_SHORT).show()
                                    cart = mapOf() // Clear cart
                                    onBack() // Or go to orders history
                                },
                            ) {
                                Text("Place Order ➔", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 120.dp, top = 8.dp)
        ) {
            items(items) { item ->
                if (item.hasSizes) {
                    val halfCartItem = CartItem(item, "Half", item.halfPrice)
                    val fullCartItem = CartItem(item, "Full", item.fullPrice)
                    CustomerMenuItemSized(
                        item = item,
                        halfQuantity = cart[halfCartItem] ?: 0,
                        fullQuantity = cart[fullCartItem] ?: 0,
                        onAddHalf = {
                            val current = cart.toMutableMap()
                            current[halfCartItem] = (cart[halfCartItem] ?: 0) + 1
                            cart = current
                        },
                        onRemoveHalf = {
                             val q = cart[halfCartItem] ?: 0
                             if (q > 0) {
                                 val current = cart.toMutableMap()
                                 if (q == 1) current.remove(halfCartItem) else current[halfCartItem] = q - 1
                                 cart = current
                             }
                        },
                        onAddFull = {
                            val current = cart.toMutableMap()
                            current[fullCartItem] = (cart[fullCartItem] ?: 0) + 1
                            cart = current
                        },
                        onRemoveFull = {
                             val q = cart[fullCartItem] ?: 0
                             if (q > 0) {
                                 val current = cart.toMutableMap()
                                 if (q == 1) current.remove(fullCartItem) else current[fullCartItem] = q - 1
                                 cart = current
                             }
                        }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                } else {
                    val defaultCartItem = CartItem(item, "Regular", item.price)
                    CustomerMenuItem(
                        item = item,
                        price = item.price,
                        quantity = cart[defaultCartItem] ?: 0,
                        onAdd = {
                            val current = cart.toMutableMap()
                            current[defaultCartItem] = (cart[defaultCartItem] ?: 0) + 1
                            cart = current
                        },
                        onRemove = {
                            val q = cart[defaultCartItem] ?: 0
                            if (q > 0) {
                                val current = cart.toMutableMap()
                                if (q == 1) current.remove(defaultCartItem) else current[defaultCartItem] = q - 1
                                cart = current
                            }
                        }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }
    }
}
}

@Composable
fun CategoryItem(title: String, iconSrc: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(72.dp)) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(color.copy(alpha = 0.2f), shape = androidx.compose.foundation.shape.CircleShape)
                .border(2.dp, color, androidx.compose.foundation.shape.CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(text = iconSrc, fontSize = 28.sp)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
    }
}

@Composable
fun CustomerMenuItemSized(
    item: MenuItem,
    halfQuantity: Int,
    fullQuantity: Int,
    onAddHalf: () -> Unit,
    onRemoveHalf: () -> Unit,
    onAddFull: () -> Unit,
    onRemoveFull: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                    Text(text = item.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Half: ₹${item.halfPrice} • Full: ₹${item.fullPrice}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    if (item.description.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = item.description, fontSize = 14.sp, color = Color.Gray, maxLines = 2)
                    }
                }
                if (item.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model = item.imageUrl,
                        contentDescription = item.name,
                        modifier = Modifier.size(100.dp).clip(RoundedCornerShape(12.dp)),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Half", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    if (halfQuantity == 0) {
                        OutlinedButton(
                            onClick = onAddHalf,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                        ) { Text("ADD", fontWeight = FontWeight.Bold) }
                    } else {
                        QuantitySelector(quantity = halfQuantity, onIncrease = onAddHalf, onDecrease = onRemoveHalf)
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Full", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    if (fullQuantity == 0) {
                        OutlinedButton(
                            onClick = onAddFull,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                        ) { Text("ADD", fontWeight = FontWeight.Bold) }
                    } else {
                        QuantitySelector(quantity = fullQuantity, onIncrease = onAddFull, onDecrease = onRemoveFull)
                    }
                }
            }
        }
    }
}

@Composable
fun QuantitySelector(quantity: Int, onIncrease: () -> Unit, onDecrease: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(8.dp))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        IconButton(onClick = onDecrease, modifier = Modifier.size(32.dp)) {
            Text("-", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = 18.sp)
        }
        Text(text = "$quantity", modifier = Modifier.padding(horizontal = 8.dp), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
        IconButton(onClick = onIncrease, modifier = Modifier.size(32.dp)) {
            Text("+", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = 18.sp)
        }
    }
}

@Composable
fun CustomerMenuItem(
    item: MenuItem,
    price: Double,
    quantity: Int,
    onAdd: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                Text(text = item.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "₹$price", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                if (item.description.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = item.description, fontSize = 14.sp, color = Color.Gray, maxLines = 2)
                }
            }
            
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (item.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model = item.imageUrl,
                        contentDescription = item.name,
                        modifier = Modifier.size(100.dp).clip(RoundedCornerShape(12.dp)),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
                
                if (quantity == 0) {
                    OutlinedButton(
                        onClick = onAdd,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                    ) { Text("ADD", fontWeight = FontWeight.Bold) }
                } else {
                    QuantitySelector(quantity = quantity, onIncrease = onAdd, onDecrease = onRemove)
                }
            }
        }
    }
}

@Composable
fun AddItemDialog(onDismiss: () -> Unit, onAdd: (MenuItem) -> Unit) {
    EditItemDialog(item = null, onDismiss = onDismiss, onUpdate = { updates ->
        // Map updates to MenuItem
        val newItem = MenuItem(
            name = updates["name"] as? String ?: "",
            price = updates["price"] as? Double ?: 0.0,
            hasSizes = updates["hasSizes"] as? Boolean ?: false,
            halfPrice = updates["halfPrice"] as? Double ?: 0.0,
            fullPrice = updates["fullPrice"] as? Double ?: 0.0,
            imageUrl = updates["imageUrl"] as? String ?: ""
        )
        onAdd(newItem)
    })
}

@Composable
fun EditItemDialog(item: MenuItem?, onDismiss: () -> Unit, onUpdate: (Map<String, Any>) -> Unit) {
    var name by remember { mutableStateOf(item?.name ?: "") }
    var price by remember { mutableStateOf(item?.price?.toString() ?: "") }
    var hasSizes by remember { mutableStateOf(item?.hasSizes ?: false) }
    var halfPrice by remember { mutableStateOf(item?.halfPrice?.toString() ?: "") }
    var fullPrice by remember { mutableStateOf(item?.fullPrice?.toString() ?: "") }
    var imageUrl by remember { mutableStateOf(item?.imageUrl ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (item == null) "Add New Item" else "Update ${item.name}") },
        text = {
            LazyColumn {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Item Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = imageUrl,
                        onValueChange = { imageUrl = it },
                        label = { Text("Image URL") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = hasSizes, onCheckedChange = { hasSizes = it })
                        Text("Has Half/Full Plate options")
                    }
                    
                    if (hasSizes) {
                        OutlinedTextField(
                            value = halfPrice,
                            onValueChange = { halfPrice = it },
                            label = { Text("Half Plate Price (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = fullPrice,
                            onValueChange = { fullPrice = it },
                            label = { Text("Full Plate Price (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        OutlinedTextField(
                            value = price,
                            onValueChange = { price = it },
                            label = { Text("Price (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val updates = mutableMapOf<String, Any>()
                updates["name"] = name
                updates["imageUrl"] = imageUrl
                updates["hasSizes"] = hasSizes
                if (hasSizes) {
                    updates["halfPrice"] = halfPrice.toDoubleOrNull() ?: 0.0
                    updates["fullPrice"] = fullPrice.toDoubleOrNull() ?: 0.0
                } else {
                    updates["price"] = price.toDoubleOrNull() ?: 0.0
                }
                onUpdate(updates)
            }) {
                Text(if (item == null) "Add" else "Update")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun OrderCard(order: Order, isProvider: Boolean) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Order #${order.orderId.take(8)}", fontWeight = FontWeight.Bold)
            if (isProvider) {
                Text("Customer: ${order.userName} (${order.userPhone})")
                Text("Location: ${order.userLocation}")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Divider()
            Spacer(modifier = Modifier.height(8.dp))
            order.items.forEach { orderItem ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${orderItem.quantity}x ${orderItem.name} (${orderItem.size})")
                    Text("₹${orderItem.price * orderItem.quantity}")
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Divider()
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Packaging Fee")
                Text("₹${order.packagingFee}")
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Delivery Fee")
                Text("₹${order.deliveryFee}")
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total", fontWeight = FontWeight.Bold)
                Text("₹${order.totalAmount}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            
            if (isProvider && order.status == OrderStatus.PENDING) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { OrderRepository.updateOrderStatus(order.orderId, OrderStatus.DELIVERED) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Mark as Delivered")
                }
            }
        }
    }
}

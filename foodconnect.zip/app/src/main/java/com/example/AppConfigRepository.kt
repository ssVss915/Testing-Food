package com.example

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppConfig(
    val deliveryFee: Double = 0.0,
    val packagingFee: Double = 0.0
)

object AppConfigRepository {
    private val db = FirebaseFirestore.getInstance()
    private val configDoc = db.collection("config").document("app_fees")

    private val _config = MutableStateFlow(AppConfig())
    val config: StateFlow<AppConfig> = _config.asStateFlow()

    init {
        configDoc.addSnapshotListener { snapshot, e ->
            if (e != null) return@addSnapshotListener
            if (snapshot != null && snapshot.exists()) {
                val currentConfig = snapshot.toObject(AppConfig::class.java)
                if (currentConfig != null) {
                    _config.value = currentConfig
                }
            } else {
                // Initialize if not exists
                configDoc.set(AppConfig())
            }
        }
    }

    fun updateFees(deliveryFee: Double, packagingFee: Double) {
        configDoc.set(AppConfig(deliveryFee, packagingFee))
    }
}

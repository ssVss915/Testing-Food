package com.example

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object OrderRepository {
    private val db = FirebaseFirestore.getInstance()
    private val ordersCollection = db.collection("orders")

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    init {
        ordersCollection.orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) return@addSnapshotListener
                if (snapshot != null) {
                    val items = snapshot.documents.mapNotNull { it.toObject(Order::class.java) }
                    _orders.value = items
                    cleanupOldOrders(items)
                }
            }
    }

    private fun cleanupOldOrders(items: List<Order>) {
        val oneDayAgo = System.currentTimeMillis() - (24 * 60 * 60 * 1000)
        items.forEach { order ->
            if (order.status == OrderStatus.DELIVERED && order.timestamp < oneDayAgo) {
                ordersCollection.document(order.orderId).delete()
            }
        }
    }

    fun placeOrder(order: Order) {
        ordersCollection.document(order.orderId).set(order)
    }

    fun updateOrderStatus(orderId: String, status: OrderStatus) {
        ordersCollection.document(orderId).update("status", status.name)
    }
}

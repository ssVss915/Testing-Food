package com.example

import java.util.UUID

data class MenuItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val price: Double = 0.0, // For simple items
    val description: String = "",
    val imageUrl: String = "",
    val hasSizes: Boolean = false,
    val halfPrice: Double = 0.0,
    val fullPrice: Double = 0.0
)

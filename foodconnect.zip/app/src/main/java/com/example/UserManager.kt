package com.example

import android.content.Context
import android.content.SharedPreferences

data class UserProfile(
    val name: String = "",
    val phone: String = "",
    val location: String = ""
)

object UserManager {
    private const val PREFS_NAME = "FoodConnectPrefs"
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun saveProfile(profile: UserProfile) {
        prefs?.edit()?.apply {
            putString("name", profile.name)
            putString("phone", profile.phone)
            putString("location", profile.location)
            apply()
        }
    }

    fun getProfile(): UserProfile {
        return UserProfile(
            name = prefs?.getString("name", "") ?: "",
            phone = prefs?.getString("phone", "") ?: "",
            location = prefs?.getString("location", "") ?: ""
        )
    }

    fun isProfileComplete(): Boolean {
        val profile = getProfile()
        return profile.name.isNotBlank() && profile.phone.isNotBlank() && profile.location.isNotBlank()
    }
}

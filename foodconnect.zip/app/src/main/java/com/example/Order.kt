package com.example

import java.util.UUID

data class Order(
    val orderId: String = UUID.randomUUID().toString(),
    val userName: String = "",
    val userPhone: String = "",
    val userLocation: String = "",
    val items: List<OrderItem> = emptyList(),
    val itemTotal: Double = 0.0,
    val deliveryFee: Double = 0.0,
    val packagingFee: Double = 0.0,
    val totalAmount: Double = 0.0,
    val status: OrderStatus = OrderStatus.PENDING,
    val timestamp: Long = System.currentTimeMillis()
)

data class OrderItem(
    val menuItemId: String = "",
    val name: String = "",
    val quantity: Int = 1,
    val size: String = "Regular", // "Regular", "Half", "Full"
    val price: Double = 0.0
)

enum class OrderStatus {
    PENDING, DELIVERED, CANCELLED
}

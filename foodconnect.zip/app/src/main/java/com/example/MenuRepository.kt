package com.example

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

object MenuRepository {
    private val db = FirebaseFirestore.getInstance()
    private val menuCollection = db.collection("menu_items")

    private val _menuItems = MutableStateFlow<List<MenuItem>>(emptyList())
    val menuItems: StateFlow<List<MenuItem>> = _menuItems.asStateFlow()

    init {
        menuCollection.addSnapshotListener { snapshot, e ->
            if (e != null) {
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val items = snapshot.documents.mapNotNull { it.toObject(MenuItem::class.java) }
                _menuItems.value = items
            }
        }
    }

    fun addItem(item: MenuItem) {
        menuCollection.document(item.id).set(item)
    }

    fun updateItem(id: String, updates: Map<String, Any>) {
        menuCollection.document(id).update(updates)
    }

    fun deleteItem(id: String) {
        menuCollection.document(id).delete()
    }
}
